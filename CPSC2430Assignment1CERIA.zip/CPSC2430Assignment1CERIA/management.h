#include <iostream>
#include <string>

using namespace std;

// Defining the class
class Animol {
    public:
    
    // Class elements:
    string ani; // Either a cat or dog
    string nametag; // name of cat/dog
    
    // Methods:
    
};

// Function defining:
void add_animal();
void adopt(int decision);
